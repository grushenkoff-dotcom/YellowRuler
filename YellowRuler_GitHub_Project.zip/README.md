# Yellow Ruler

Экранная линейка 0–150 мм с жёлтым фоном.

## Сборка

GitHub Actions использует macOS 26 и Xcode 26.6.

После запуска workflow:
Actions → Build Yellow Ruler IPA → Artifacts → YellowRuler-IPA.

IPA собирается без Apple Developer signing. Для установки через SideStore его нужно подписать самим SideStore.

## Важно

Положение делений зависит от калибровки. Открой приложение, нажми «Калибровка», измерь известный отрезок и введи его длину и соответствующее число пикселей.
